# TODO: Define Pydantic models
