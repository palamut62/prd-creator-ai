# INITIAL

## FEATURE:

- Pydantic AI çoklu ajan: birincil **Research Agent** ve “ajan-olarak-araç” şeklinde **Email Draft Agent**.
- **Brave API** entegrasyonu (araştırma), **Gmail API** entegrasyonu (taslak oluşturma).
- **CLI** üzerinden gerçek zamanlı akış; araç kullanımlarının görünürlüğü.
- Çoklu LLM sağlayıcı desteği (OpenAI / OpenRouter) için **providers.py**.

## EXAMPLES:

`examples/` benzeri bir yapıdan **desen** alın; **birebir kopyalama yapmayın**. Aşağıdaki parçalar ilham içindir:
- `examples/cli.py` — CLI akış/streaming yapısı
- `examples/agent/` — ajan oluşturma, bağımlılık yönetimi, araç ekleme desenleri

## DOCUMENTATION:
- Pydantic AI: https://ai.pydantic.dev/
- Gmail API (draft): https://developers.google.com/gmail/api/guides/sending
- Brave Search API: https://api-dashboard.search.brave.com/app/documentation

## OTHER CONSIDERATIONS:
- `.env.example` sağlayın; Gmail ve Brave kurulum adımlarını **README**'ye ekleyin.
- Proje yapısını README’de gösterin.
- `python-dotenv` ile ortam değişkenlerini yükleyin.
- İlk Gmail çalıştırmasında OAuth2 akışını anlatın (credentials/).

## PROJECT STRUCTURE (hedef)
```
.
├── agents/
│   ├── research_agent.py
│   ├── email_agent.py
│   ├── providers.py
│   └── models.py
├── tools/
│   ├── brave_search.py
│   └── gmail_tool.py
├── config/
│   └── settings.py
├── tests/
│   ├── test_research_agent.py
│   ├── test_email_agent.py
│   ├── test_brave_search.py
│   ├── test_gmail_tool.py
│   └── test_cli.py
├── cli.py
├── .env.example
├── requirements.txt
├── README.md
└── credentials/.gitkeep
```

## ENVIRONMENT
`.env.example` içeriği (örnek):
```
# LLM
LLM_PROVIDER=openai
LLM_API_KEY=sk-...
LLM_MODEL=gpt-4o-mini

# Brave
BRAVE_API_KEY=

# Gmail OAuth
GMAIL_CREDENTIALS_PATH=./credentials/credentials.json
GMAIL_TOKEN_PATH=./credentials/token.json
```

## QUICKSTART
```
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python cli.py
```

## QUALITY GATES
- `ruff check . --fix`
- `mypy .`
- `pytest -v --cov=agents --cov=tools --cov-report=term-missing`

## NOTES
- Senkron fonksiyonları async bağlamında kullanmayın.
- API oran limitleri için geriye dönüş ve hata mesajlarını açık yazın.
- credentials/ altındaki dosyaları **asla** commit etmeyin.