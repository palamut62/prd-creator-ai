# Multi-Agent Research & Email Draft System

See GENEL-PRD.md and INITIAL.md
