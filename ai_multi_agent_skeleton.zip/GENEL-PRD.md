# GENEL-PRD.md — AI Çoklu Ajan Üretim Hattı (Domain-Agnostic)

**Sürüm:** 1.0  
**Tarih:** 2025-08-11  
**Proje Adı (örnek):** Multi-Agent Research & Email Draft System  
**Amaç:** Kullanıcının verdiği talebe göre uygun dil/platform seçimi yapıp, çoklu ajan mimarisiyle üretim hattını uçtan uca (analiz → tasarım → kod → test → paketleme → dağıtım) otomatikleştirmek.

---

## 1) Özet
- **Kapsam:** Pydantic AI tabanlı birincil “Research Agent” (Brave Search API) ve “Email Draft Agent” (Gmail API) ile agent-as-tool deseni.
- **Hedefler:** CLI üstünden gerçek zamanlı akış, çoklu LLM sağlayıcı desteği, güvenli kimlik bilgisi yönetimi, test ve kalite kapıları.
- **Çıktılar:** Kod iskeleti, testler, CI hattı, dokümantasyon, .env örneği, dağıtım profili.

---

## 2) Gereksinimler

### 2.1 Kullanıcı Talebi (örnek)
> “Araştırma yap, bulguları özetle ve belirttiğim kişiye Gmail taslağı oluştur.”

### 2.2 İşlevsel Gereksinimler
- [ ] CLI girdisinden araştırma sorgusu alınır.
- [ ] Research Agent, Brave API ile arama yapar ve sonuçları yapılandırır.
- [ ] Research Agent, Email Draft Agent’ı **araç** olarak çağırarak Gmail Taslağı oluşturur.
- [ ] Akış (streaming) ve kullanılan araçların görünürlüğü CLI üzerinde gösterilir.
- [ ] Çoklu LLM (ör. OpenAI, OpenRouter) sağlayıcı desteği **providers.py** üzerinden yapılandırılabilir.

### 2.3 İşlevsel Olmayan Gereksinimler
- **Performans:** p95 CLI yanıtı < 3 sn (harici API sürelerine bağlı).
- **Güvenlik:** OAuth2 (Gmail), API anahtarları .env, gizli dosyalar repoya girmeyecek.
- **Uyum:** KVKK/GDPR kapsamında PII verileri loglarda maskele.
- **Gözlemlenebilirlik:** Temel log, hata yakalama, minimal metrikler.
- **Kalite:** Lint + type-check + ≥%80 test kapsamı hedefi.

---

## 3) Teknoloji Seçim Matrisi (örnek doldurum)

| Kategori  | Alternatifler                         | Artıları                                  | Eksileri                               | Seçilen |
|-----------|---------------------------------------|-------------------------------------------|----------------------------------------|---------|
| Backend/Ajan | Python + Pydantic AI                | Zengin tip doğrulama, async destek        | Yeni ekosistem öğrenme eğrisi          | ✅      |
| CLI       | Python (asyncio, rich/typer opsiyonel)| Hızlı geliştirme                           | Paket boyutu                            | ✅      |
| Arama     | Brave Search API                      | Temiz REST, makul kota                    | Ücretsiz planda limit                  | ✅      |
| Email     | Gmail API (draft)                     | Yaygın, güçlü ekosistem                   | İlk çalıştırmada OAuth2 akışı          | ✅      |
| LLM       | OpenAI / OpenRouter                   | Çoklu model seçeneği                      | Fiyat/latency değişken                  | ✅      |
| Test      | pytest + coverage                     | Basit, yaygın                             | —                                      | ✅      |
| Lint/Tip  | ruff + mypy                           | Hızlı ve güvenilir                        | Tip ekleme eforu                       | ✅      |

**Gerekçe:** Pydantic AI ile agent-as-tool kalıbını minimum sürtünmeyle kurmak mümkün. Python ekosistemi Gmail/Brave SDK/HTTP istemcileri için olgun.

---

## 4) Mimari

### 4.1 Diyagram (sözel)
CLI → Research Agent → (tool) Brave Search → sonuçları yapılandır → (tool) Email Draft Agent → Gmail taslağı oluştur → CLI’ya akış.

### 4.2 Bileşenler
- **agents/**: research_agent.py, email_agent.py, providers.py, models.py  
- **tools/**: brave_search.py, gmail_tool.py  
- **config/**: settings.py (.env yükleme ve tipli ayarlar)  
- **tests/**: birim ve entegrasyon testleri  
- **cli.py**: uçbirim arayüzü

---

## 5) Profiller ve Şablonlar
- **Profil:** `/profiles/backend-pydantic-ai.md` (bu proje için örnek)
- **Şablonlar:** `/templates/backend/pydantic-ai/` altında kod iskeleti

---

## 6) Kabul Kriterleri
- [ ] Brave araması çalışır, sonuçlar tipli modellere döner.
- [ ] Gmail OAuth2 akışı tamamlanır, taslak başarıyla oluşur.
- [ ] Research Agent → Email Agent aracı çağrısı akıcıdır.
- [ ] CLI akışlı çıktı üretir; araç kullanımları görünürdür.
- [ ] Testler ≥%80 kapsam ve CI’de yeşil.

---

## 7) Otomasyon Akış Planı (AI Pipeline)
| Aşama                  | Tahmini Süre | Sorumlu Ajan        | Bağımlılıklar                  |
|------------------------|--------------|---------------------|--------------------------------|
| Gereksinim Analizi     | 30 sn        | Requirements Agent  | —                              |
| Teknoloji Seçimi       | 15 sn        | Tech-Selection Agent| 1                              |
| Mimari Tasarım         | 45 sn        | Architect Agent     | 1,2                            |
| Kod Üretimi            | 2–5 dk       | Codegen Agents      | 3                              |
| Test & Doğrulama       | 1–2 dk       | QA Agent            | 4                              |
| Paketleme & Dağıtım    | 30 sn        | Deploy Agent        | 5 (tüm testler yeşil)          |

> Süreler “insan haftası” değil; **işlem süresi** (execution time) tahminidir.

---

## 8) Riskler & Önlemler
- **Gmail OAuth UX:** İlk çalıştırmada tarayıcı açılır; README’de adım adım kurulum.  
- **API Limitleri:** Brave rate limit; exponential backoff + testlerde mock.  
- **Gizli Anahtarlar:** .env, credentials/ klasörü .gitignore; SBOM ve secret scan.

---

## 9) Ekler (Bağlantılar)
- Pydantic AI Agents: https://ai.pydantic.dev/agents/  
- Multi-agent Applications: https://ai.pydantic.dev/multi-agent-applications/  
- Gmail Drafts: https://developers.google.com/gmail/api/guides/sending  
- Brave Search API: https://api-dashboard.search.brave.com/app/documentation