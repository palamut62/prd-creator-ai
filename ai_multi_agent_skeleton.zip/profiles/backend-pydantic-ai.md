# Profil: Backend (Pydantic AI)

- Dağıtım: Docker + GH Actions
- Test: pytest, coverage
- Güvenlik: secrets scan
